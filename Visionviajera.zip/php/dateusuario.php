<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VISION VIAJERA </title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js">
</head>
<body>
    <div class="container my-5">
         <h2> list of clients</h2>
         <a class="btn btn-primary" href="/visionviajera/create.php" role="button">New client</a>
         <br>
         <table class="table">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Nombre Usuario</th>
                    <th>Apellido Usuario</th>
                    <th>Nombre</th>
                    <th>Contraseña</th>
                    <th>tipo</th>
                    <th>Email</th>
                </tr>     
            </thead>
         </table> 
   </div>
    
</body>
</html>