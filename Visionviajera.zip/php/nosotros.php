<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosotros</title>
</head>
<body>
<div class="card ">
              <img src="../imagenes/nosotros.jpeg" 
     width="100%"
    height="15%">


</body>
</html>