<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio pagina</title>
</head>
<body>
    <div class="fondo">
    <img src="../imagenes/inicio.jpeg" 
     width="100%"
    height="15%"
  >
</div>
    
</body>

</html>