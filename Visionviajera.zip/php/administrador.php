<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../css/estilos.css">
</head>

<body>
	
	<nav>
		<!-- Aquí va el menú -->
		<ul>
			<li><a href="../crudusuarios/index.php" >Usuario</a></li>
			<li><a href="../crudhotel/index.php">Hotel</a></li>
			<li><a href="../crudDestino/index.php">Destino</a></li>
		</ul>
	</nav>
</body>
</html>